import heapq
import uuid
from datetime import datetime

users = {
    "admin": {"password": "admin123", "role": "admin"},
    "konsumen": {"password": "user123", "role": "user"}
}

pengiriman = []


class Graph:
    def __init__(self):
        self.graph = {}

    def tambah_kota(self, kota):
        if kota not in self.graph:
            self.graph[kota] = []

    def hapus_kota(self, kota):
        if kota not in self.graph:
            return

        del self.graph[kota]

        for node in self.graph:
            self.graph[node] = [
                (t, j) for t, j in self.graph[node]
                if t != kota
            ]

    def tambah_jalur(self, asal, tujuan, jarak):
        self.tambah_kota(asal)
        self.tambah_kota(tujuan)

        self.graph[asal].append((tujuan, jarak))
        self.graph[tujuan].append((asal, jarak))

    def hapus_jalur(self, asal, tujuan):
        if asal in self.graph:
            self.graph[asal] = [
                (n, d) for n, d in self.graph[asal]
                if n != tujuan
            ]

        if tujuan in self.graph:
            self.graph[tujuan] = [
                (n, d) for n, d in self.graph[tujuan]
                if n != asal
            ]

    def tampilkan_graph(self):
        print("\n===== GRAPH =====")

        for kota in self.graph:
            print(f"\n{kota}")

            for tujuan, jarak in self.graph[kota]:
                print(f" --> {tujuan} ({jarak} km)")

    def dijkstra(self, start, end):

        if start not in self.graph or end not in self.graph:
            return [], float("inf")

        distances = {
            city: float("inf")
            for city in self.graph
        }

        previous = {
            city: None
            for city in self.graph
        }

        distances[start] = 0

        pq = [(0, start)]

        while pq:

            current_distance, current_city = heapq.heappop(pq)

            if current_distance > distances[current_city]:
                continue

            for neighbor, weight in self.graph[current_city]:

                distance = current_distance + weight

                if distance < distances[neighbor]:

                    distances[neighbor] = distance
                    previous[neighbor] = current_city

                    heapq.heappush(
                        pq,
                        (distance, neighbor)
                    )

        if distances[end] == float("inf"):
            return [], float("inf")

        path = []
        current = end

        while current:
            path.append(current)
            current = previous[current]

        path.reverse()

        return path, distances[end]


navigator = Graph()

jalur_awal = [
    ("Jakarta", "Bandung", 150),
    ("Jakarta", "Semarang", 440),
    ("Bandung", "Semarang", 290),
    ("Semarang", "Surabaya", 340),
    ("Bandung", "Yogyakarta", 360),
    ("Yogyakarta", "Surabaya", 315)
]

for a, b, c in jalur_awal:
    navigator.tambah_jalur(a, b, c)


def login():
    print("\n===== LOGIN =====")

    username = input("Username : ")
    password = input("Password : ")

    if username in users:
        if users[username]["password"] == password:
            print("Login berhasil")
            return users[username]["role"]

    print("Login gagal")
    return None


def cari_rute():
    asal = input("Kota Asal : ")
    tujuan = input("Kota Tujuan : ")

    path, distance = navigator.dijkstra(
        asal,
        tujuan
    )

    if not path:
        print("Rute tidak ditemukan")
        return

    print("\nRute :", " -> ".join(path))
    print("Jarak :", distance, "km")


def hitung_biaya(
        jarak,
        berat,
        kendaraan,
        prioritas):

    tarif = {
        "motor": 1000,
        "mobil": 2000,
        "truk": 3000
    }

    biaya = jarak * tarif[kendaraan]
    biaya += berat * 5000

    if prioritas == "express":
        biaya *= 1.5

    elif prioritas == "same_day":
        biaya *= 2

    return biaya


def estimasi(jarak, kendaraan):

    speed = {
        "motor": 40,
        "mobil": 60,
        "truk": 80
    }

    return round(
        jarak / speed[kendaraan],
        2
    )


def kirim_barang():

    asal = input("Asal : ").strip()
    tujuan = input("Tujuan : ").strip()

    if asal == "" or tujuan == "":
        print("Asal dan tujuan tidak boleh kosong!")
        return

    barang = input("Nama Barang : ").strip()

    if barang == "":
        print("Nama barang tidak boleh kosong!")
        return

    try:
        berat = float(input("Berat (Kg) : "))

        if berat <= 0:
            print("Berat harus lebih dari 0")
            return

    except ValueError:
        print("Berat harus berupa angka")
        return

    kendaraan = input(
        "motor/mobil/truk : "
    ).strip().lower()

    while kendaraan not in ["motor", "mobil", "truk"]:
        print("Pilihan kendaraan tidak valid")
        kendaraan = input(
            "motor/mobil/truk : "
        ).strip().lower()

    prioritas = input(
        "reguler/express/same_day : "
    ).strip().lower()

    while prioritas not in [
        "reguler",
        "express",
        "same_day"
    ]:
        print("Pilihan prioritas tidak valid")
        prioritas = input(
            "reguler/express/same_day : "
        ).strip().lower()

    path, distance = navigator.dijkstra(
        asal,
        tujuan
    )

    if not path:
        print("Rute tidak ditemukan")
        return

    biaya = hitung_biaya(
        distance,
        berat,
        kendaraan,
        prioritas
    )

    resi = str(uuid.uuid4())[:8].upper()

    pengiriman.append({
        "resi": resi,
        "barang": barang,
        "asal": asal,
        "tujuan": tujuan,
        "berat": berat,
        "jarak": distance,
        "biaya": biaya,
        "status": "Diproses",
        "history": [
            f"{datetime.now()} - Diproses"
        ]
    })

    print("\n===== DATA PENGIRIMAN =====")
    print("Resi      :", resi)
    print("Barang    :", barang)
    print("Rute      :", " -> ".join(path))
    print("Jarak     :", distance, "km")
    print("Estimasi  :", estimasi(distance, kendaraan), "jam")
    print("Biaya     : Rp", format(int(biaya), ","))

def lacak_pengiriman():

    resi = input("Masukkan Resi : ")

    for p in pengiriman:

        if p["resi"] == resi:

            print("\nStatus :", p["status"])

            print("\nRiwayat :")

            for h in p["history"]:
                print("-", h)

            return

    print("Resi tidak ditemukan")


def update_status():

    resi = input("Resi : ").strip()

    daftar = [
        "Diproses",
        "Dijemput",
        "Di Gudang",
        "Dalam Perjalanan",
        "Sampai Tujuan",
        "Diantar Kurir",
        "Selesai"
    ]

    for p in pengiriman:

        if p["resi"] == resi:

            print("\n===== UPDATE STATUS =====")

            for i, s in enumerate(daftar, 1):
                print(f"{i}. {s}")

            try:
                pilih = int(input("Pilih Status : "))

                if pilih < 1 or pilih > len(daftar):
                    print("Pilihan tidak valid")
                    return

            except ValueError:
                print("Masukkan angka")
                return

            p["status"] = daftar[pilih - 1]

            p["history"].append(
                f"{datetime.now()} - {p['status']}"
            )

            print("Status berhasil diperbarui")
            return

    print("Resi tidak ditemukan")

def statistik():
    print("\n===== STATISTIK PENGIRIMAN =====")
    print("Total pengiriman:", len(pengiriman))

    total_biaya = sum(p["biaya"] for p in pengiriman)
    print("Total pemasukan: Rp", format(int(total_biaya), ","))

    status_count = {}

    for p in pengiriman:
        status = p["status"]
        status_count[status] = status_count.get(status, 0) + 1

    print("\nStatus Pengiriman:")
    for status, jumlah in status_count.items():
        print(f"- {status}: {jumlah}")


# =====================================
# MENU ADMIN
# =====================================
def menu_admin():
    while True:
        print("""
====================================
            MENU ADMIN
====================================
1. Tambah Kota
2. Hapus Kota
3. Tambah Jalur
4. Hapus Jalur
5. Tampilkan Graph
6. Cari Rute
7. Kirim Barang
8. Lacak Pengiriman
9. Update Status
10. Statistik
11. Logout
====================================
""")

        pilih = input("Pilih Menu : ")

        if pilih == "1":
            kota = input("Nama Kota : ")
            navigator.tambah_kota(kota)
            print("Kota berhasil ditambahkan")

        elif pilih == "2":
            kota = input("Nama Kota : ")
            navigator.hapus_kota(kota)
            print("Kota berhasil dihapus")

        elif pilih == "3":
            asal = input("Kota Asal : ")
            tujuan = input("Kota Tujuan : ")
            jarak = int(input("Jarak (km) : "))

            navigator.tambah_jalur(
                asal,
                tujuan,
                jarak
            )

            print("Jalur berhasil ditambahkan")

        elif pilih == "4":
            asal = input("Kota Asal : ")
            tujuan = input("Kota Tujuan : ")

            navigator.hapus_jalur(
                asal,
                tujuan
            )

            print("Jalur berhasil dihapus")

        elif pilih == "5":
            navigator.tampilkan_graph()

        elif pilih == "6":
            cari_rute()

        elif pilih == "7":
            kirim_barang()

        elif pilih == "8":
            lacak_pengiriman()

        elif pilih == "9":
            update_status()

        elif pilih == "10":
            statistik()

        elif pilih == "11":
            print("Logout Admin Berhasil")
            break

        else:
            print("Menu tidak tersedia")


# =====================================
# MENU KONSUMEN
# =====================================
def menu_konsumen():
    while True:
        print("""
====================================
          MENU KONSUMEN
====================================
1. Cari Rute
2. Kirim Barang
3. Lacak Pengiriman
4. Logout
====================================
""")

        pilih = input("Pilih Menu : ")

        if pilih == "1":
            cari_rute()

        elif pilih == "2":
            kirim_barang()

        elif pilih == "3":
            lacak_pengiriman()

        elif pilih == "4":
            print("Logout Konsumen Berhasil")
            break

        else:
            print("Menu tidak tersedia")


# =====================================
# PROGRAM UTAMA
# =====================================
while True:

    print("""
====================================
   SISTEM RUTE PENGIRIMAN BARANG
====================================
1. Login
2. Keluar
====================================
""")

    pilih = input("Pilih Menu : ")

    if pilih == "1":

        role = login()

        if role == "admin":
            menu_admin()

        elif role == "user":
            menu_konsumen()

    elif pilih == "2":
        print("\nTerima Kasih Telah Menggunakan Sistem")
        break

    else:
        print("Pilihan tidak valid")